#!/bin/bash
#
# Copyright (c) 2015 Gigamon Inc. All Rights Reserved
#

# Check for required arguments
if [ "$#" -ne 3 ]; then
	echo "Usage: $0 <SELF_SIGNED_PATH> <KEY_FILE_NAME> <CRT_FILE_NAME>"
	exit 1
fi


# Update variables
SELF_SIGNED_PATH=$1
KEY_FILE=${SELF_SIGNED_PATH}/$2
CRT_FILE=${SELF_SIGNED_PATH}/$3

# Ensure path exists
if [ ! -d "$SELF_SIGNED_PATH" ]; then
	echo "Error: Directory $SELF_SIGNED_PATH does not exist."
	exit 1
fi

export RANDFILE=${SELF_SIGNED_PATH}/.rnd
touch ${HOME}/.rnd

# Generate SSL key and self-signed certificate
openssl req \
	-new \
	-newkey rsa:4096 \
	-days 365 \
	-nodes \
	-x509 \
	-subj "/C=US/ST=California/L=Santa Clara/O=Gigamon Inc/CN=www.gigamon.com" \
	-keyout ${KEY_FILE} \
	-out ${CRT_FILE}

exit $?
