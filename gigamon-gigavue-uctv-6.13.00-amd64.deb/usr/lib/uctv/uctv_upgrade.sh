#!/bin/bash
#
# Copyright (c) 2024 Gigamon Inc. All Rights Reserved.
#
# Script to perform an upgrade process:
# Stopping UCT-V service, uninstalling the current package.
# Installing new package, and starting the service again.
#

# Constants
LOGFILE="/var/log/uctv-upgrade.log"
AGENT_PORT=9902

IMG_PATH="/var/lib/uctv/uctv-images"
UPG_DIR="/tmp/uctv_upgrade"

RMQ_UPDATE_SRC="/usr/lib/uctv/uctv_upgrade_status"
RMQ_UPDATE_RUN="$UPG_DIR/uctv_upgrade_status"

RMQ_CONFIG_SRC="/var/lib/uctv/data/agentCntlr_data"
RMQ_CONFIG_RUN="$UPG_DIR/agentCntlr_data"

# Global variables for image details
UPG_IMG_SRC=""
UPG_IMG_RUN=""
UPG_IMG_NAME=""
UPG_IMG_TYPE=""

# Backup Configuration, Data and Logs
TPO_SRC="/etc/gigamon-cloud.conf"
TPO_BKP="$UPG_DIR/gigamon-cloud.conf"
TPO_DEPLOYMENT="no"

ETC_PATH="/etc"
CONF_SRC="$ETC_PATH/uctv"
CONF_BKP_DIR="$UPG_DIR/conf_bkp"
CONF_BKP="$CONF_BKP_DIR/uctv"

DATA_PATH="/var/lib"
DATA_SRC="$DATA_PATH/uctv"
DATA_BKP_DIR="$UPG_DIR/data_bkp"
DATA_BKP="$DATA_BKP_DIR/uctv"

LOG_SRC="/var/log/uctv.log"
LOG_BKP="$UPG_DIR/uctv.log"

LOG_UCTV_INST_SRC="/var/log/uctv-installation.log"
LOG_UCTV_INST_BKP="$UPG_DIR/uctv-installation.log"

# Function to log messages with timestamps
log() {
	echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOGFILE"
}

# Function to send status via RMQ in the Controller
send_status() {
	for i in {1..5}; do
		sudo "$RMQ_UPDATE_RUN" "$1"
		if [ $? -eq 0 ]; then
			log "Successfully sent Status: $1 to FM"
			return
		else
			log "Couldn't sent Status $1 to FM on attempt $i"
			sleep 2
		fi
	done

	log "Failed to send Status: $1 to FM"
}


# Signal handler function
signal_handler() {
	log "Caught signal $1"
}

# Function to setup signal trapping
setup_signal_traps() {
	trap 'signal_handler 1' HUP
	trap 'signal_handler 2' INT
	trap 'signal_handler 3' QUIT
	trap 'signal_handler 15' TERM
}

#Check if it is 3PO deployment
is_3po_deployment() {
    local CONF_FILE="/etc/gigamon-cloud.conf"

    if [ -s "$CONF_FILE" ] && \
       grep -q "groupName:" "$CONF_FILE" && \
       grep -q "subGroupName:" "$CONF_FILE"; then
        return 0  #3PO deployment
    fi

    return 1  #Not a 3PO deployment
}

# Create upgrade and other directories
create_upgrade_directories() {
	if mkdir -p "$UPG_DIR";  then
		log "Successfully created $UPG_DIR"
	else
		log "Failed to create $UPG_DIR"
		cleanup
		exit 1
	fi

	if mkdir -p "$CONF_BKP_DIR";  then
		log "Successfully created $CONF_BKP_DIR"
	else
		log "Failed to create $CONF_BKP_DIR"
		cleanup
		exit 1
	fi

	if mkdir -p "$DATA_BKP_DIR";  then
		log "Successfully created $DATA_BKP_DIR"
	else
		log "Failed to create $DATA_BKP_DIR"
		cleanup
		exit 1
	fi
}

# Function to copy the status update module to the run directory
copy_status_update_module() {
	log "Copying $RMQ_UPDATE_SRC to $RMQ_UPDATE_RUN"

	if cp "$RMQ_UPDATE_SRC" "$RMQ_UPDATE_RUN"; then
		log "Successfully copied $RMQ_UPDATE_SRC to $RMQ_UPDATE_RUN"
	else
		log "Failed to copy $RMQ_UPDATE_SRC to $RMQ_UPDATE_RUN"
		cleanup
		exit 1
	fi
}

# Function to copy the agentCntlr_data file to the run directory
copy_agent_cntlr_data() {
        log "Copying $RMQ_CONFIG_SRC to $RMQ_CONFIG_RUN"

        if cp "$RMQ_CONFIG_SRC" "$RMQ_CONFIG_RUN"; then
                log "Successfully copied $RMQ_CONFIG_SRC to $RMQ_CONFIG_RUN"
        else
                log "Failed to copy $RMQ_CONFIG_SRC to $RMQ_CONFIG_RUN"
        fi
}

# Function to set global variables for image details
set_image_details() {
	UPG_IMG_SRC=$(find "$IMG_PATH" -name "gigamon*" -print -quit)
	UPG_IMG_NAME=$(basename "$UPG_IMG_SRC")
	UPG_IMG_TYPE="${UPG_IMG_NAME##*.}"
	UPG_IMG_RUN="$UPG_DIR/$UPG_IMG_NAME"

        log "Image Details - Name: $UPG_IMG_NAME, Type: $UPG_IMG_TYPE"
}

# Function to copy the image to the run directory
copy_image() {
	log "Copying $UPG_IMG_SRC to $UPG_IMG_RUN"

	if cp "$UPG_IMG_SRC" "$UPG_IMG_RUN"; then
		log "Successfully copied $UPG_IMG_SRC to $UPG_IMG_RUN"
	else
		log "Failed to copy $UPG_IMG_SRC to $UPG_IMG_RUN"
		send_status "failed"
		cleanup
		exit 1
	fi
}

# Check for any ongoing upgrade
check_ongoing_upgrade () {
	local LOCK="/var/lib/dpkg/lock-frontend"

	if [ "$UPG_IMG_TYPE" = "deb" ] && ! flock -xn "$LOCK" -c ':'; then
		log "Other upgrade is ongoing, UCT-V cannot acquire the lock to upgrade"
		send_status "failed"
		cleanup
		exit 1
	fi
}

# Function to stop the service
stop_service() {
	local CMD
	log "Stopping the existing service"

	if [ "$UPG_IMG_TYPE" = "deb" ]; then
		CMD="service uctv stop"
	else
		CMD="systemctl stop uctv"
	fi

	for i in {1..5}; do
		log "Stopping the service for the $i time"

		if eval "$CMD"; then
			log "Successfully stopped the service"
			sleep 2
			return
		fi

		# Wait 2 seconds before execution
		sleep 2
	done

	log "Failed to stop the service"
	send_status "failed"
	cleanup
	exit 1
}

# Function to backup 3PO, configuration, data, and log files
backup_config() {
	log "Backing up 3PO, configuration, data, and log files started"

	# Backup 3PO file
	if [ -f "$TPO_SRC" ]; then
		if cp "$TPO_SRC" "$TPO_BKP"; then
			log "Successfully copied $TPO_SRC to $TPO_BKP"
			TPO_DEPLOYMENT="yes"
		else
			log "Failed to copy $TPO_SRC to $TPO_BKP"
		fi
	fi

	# Backup configuration
	if cp -r "$CONF_SRC" "$CONF_BKP_DIR"; then
		log "Successfully copied $CONF_SRC to $CONF_BKP_DIR"
	else
		log "Failed to copy $CONF_SRC to $CONF_BKP_DIR"
	fi

	# No need to backup image file
	rm -f $UPG_IMG_SRC
	log "File $UPG_IMG_SRC removed"

	# Backup data
	if cp -r "$DATA_SRC" "$DATA_BKP_DIR"; then
		log "Successfully copied $DATA_SRC to $DATA_BKP_DIR"
	else
		log "Failed to copy $DATA_SRC to $DATA_BKP_DIR"
	fi

	# Backup log file
	if cp "$LOG_SRC" "$LOG_BKP"; then
		log "Successfully copied $LOG_SRC to $LOG_BKP"
	else
		log "Failed to copy $LOG_SRC to $LOG_BKP"
	fi

	if cp "$LOG_UCTV_INST_SRC" "$LOG_UCTV_INST_BKP"; then
		log "Successfully copied $LOG_UCTV_INST_SRC to $LOG_UCTV_INST_BKP"
	else
		log "Failed to copy $LOG_UCTV_INST_SRC to $LOG_UCTV_INST_BKP"
	fi

	log "Backing up 3PO, configuration, data, and log files completed"
}

# Function to uninstall the existing service
uninstall_service() {
	local CMD

	log "Uninstalling the existing service"

	if [ "$UPG_IMG_TYPE" = "deb" ]; then
		CMD="dpkg -r uctv"
	else
		CMD="rpm -e uctv"
	fi

	for i in {1..5}; do
		log "Uninstalling the service for the $i time"

		if eval "$CMD"; then
			log "Successfully uninstalled the service"
			sleep 2
			return
		fi

		# Wait 2 seconds before execution
		sleep 2
	done

	log "Failed to uninstall the service"

	#Start the service so that it runs with old version
	start_service

	# Wait for service to start
	check_service_status

	# Wait 3PO regisrtation
	check_3po_reg_status

	send_status "failed"
	cleanup
	exit 1
}

# Function to install the new service
install_service() {
	local CMD
	local PKG_RM_CMD

	log "Installing the new service from $UPG_IMG_RUN"

	if [ "$UPG_IMG_TYPE" = "deb" ]; then
		CMD="dpkg -i $UPG_IMG_RUN"
		PKG_RM_CMD="dpkg -r uctv"
	else
		CMD="rpm -i $UPG_IMG_RUN"
		PKG_RM_CMD="rpm -e uctv"
	fi

	for i in {1..5}; do
		log "Installing the service for the $i time"

		if $CMD; then
			log "Successfully installed the new service"
			sleep 2
			return
		else
			#Remove any stale files
			eval "$PKG_RM_CMD" 2>/dev/null
		fi

		# Wait 2 seconds before execution
		sleep 2
	done

	log "Failed to install the new service"
	send_status "failed"
	cleanup
	exit 1
}

# Function to restore UCT-V Config & Data
restore_config() {
	local BUILD_INFO_FILE="/usr/lib/uctv/build_info.txt"
	local CHECKSUM_FILE="$DATA_BKP/uctv-images/checksum"

	log "Restoring 3PO, configuration, data, and log files started"

	# Restore 3PO file
	if [ $TPO_DEPLOYMENT == "yes" ]; then
		if cp "$TPO_BKP" "$TPO_SRC"; then
			log "Successfully copied $TPO_BKP to $TPO_SRC"
		else
			log "Failed to copy $TPO_BKP to $TPO_SRC"
		fi
	fi

	# Restore configuration
	if cp -r "$CONF_BKP" "$ETC_PATH"; then
		log "Successfully copied $CONF_BKP to $ETC_PATH"
	else
		log "Failed to copy $CONF_BKP to $ETC_PATH"
	fi

	# Update checksum
	CHECKSUM=$(cat "$CHECKSUM_FILE")
	echo -e "Checksum    : $CHECKSUM" >> "$BUILD_INFO_FILE"

	# Restore data
	if cp -r "$DATA_BKP" "$DATA_PATH"; then
		log "Successfully copied $DATA_BKP to $DATA_PATH"
	else
		log "Failed to copy $DATA_BKP to $DATA_PATH"
	fi

	# Restore log file
	if cp "$LOG_BKP" "$LOG_SRC"; then
		log "Successfully copied $LOG_BKP to $LOG_SRC"
	else
		log "Failed to copy $LOG_BKP to $LOG_SRC"
	fi

	if cp "$LOG_UCTV_INST_BKP" "$LOG_UCTV_INST_SRC"; then
                log "Successfully copied $LOG_UCTV_INST_BKP to $LOG_UCTV_INST_SRC"
	else
                log "Failed to copy $LOG_UCTV_INST_BKP to $LOG_UCTV_INST_SRC"
	fi

	log "Restoring 3PO, configuration, data, and log files completed"
}

# Function to start the new service
start_service() {
	local CMD

	log "Starting the new service"

	if [ "$UPG_IMG_TYPE" = "deb" ]; then
		CMD="service uctv start"
	else
		CMD="systemctl start uctv"
	fi

	if $CMD; then
		log "Successfully started the new service"
	else
		log "Failed to start the new service"
		send_status "failed"
		cleanup
		exit 1
	fi
	#wait for service to start
	sleep 2
}

# Function to check service status
check_service_status() {
	local PID
	local CMD
	local OUTPUT

	log "Checking for UCT-V service status"

	# Check if 'ss' command is available
	if command -v ss >/dev/null 2>&1; then
		# Loop for 5 iterations
		for i in {1..5}
		do
			OUTPUT=$(ss -tuln | grep "$AGENT_PORT")

			# Check if port is in listening mode
			if echo "$OUTPUT" | grep -q "LISTEN"; then
				log "Service port $AGENT_PORT is in listening mode"
				break
			fi

			# Wait for 2 second before the next iteration
			sleep 2
		done
	fi

	# Loop for 20 iterations
	for i in {1..20}
	do
	OUTPUT=$(LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 /usr/lib/uctv/uctvl uctv-show)

		# Check if the "State : On" is present in the output
		if echo "$OUTPUT" | grep -q "State   : On"; then
			log "Service is in On state"
			return
		fi

		# Wait for 2 second before the next iteration
		sleep 2
	done


	# Check for the process ID (PID) of the "uctvd" process
	PID=$(pgrep -f "uctvd" | head -n 1)

	# If the PID is found, kill the process
	if [[ -n "$PID" ]]; then
		log "Killing process uctvd with PID: $PID"
		sudo kill -9 "$PID"
	else
		log "No uctvd process found running"
	fi

	#Restart the "uctv" service
	if [ "$UPG_IMG_TYPE" = "deb" ]; then
		CMD="service uctv restart"
	else
		CMD="systemctl restart uctv"
	fi

	if $CMD; then
		log "Successfully restarted the new service"
	else
		log "Failed to restart the new service"
	fi

	# Wait for 2 second for restart
	sleep 2

	# Loop for 10 iterations
	for i in {1..10}
	do
		OUTPUT=$(LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 /usr/lib/uctv/uctvl uctv-show)

		# Check if the "State : On" is present in the output
		if echo "$OUTPUT" | grep -q "State   : On"; then
			log "Service is in On state"
			return
		fi

		# Wait for 1 second before the next iteration
		sleep 2
	done

	log "Failed to get service to On state"
	send_status "failed"
	cleanup
	exit 1
}

# Function to check 3PO registration status
check_3po_reg_status() {
	# Proceed iff it is 3PO deployment
	if ! is_3po_deployment; then
		return
	fi

	local TPO_LOG_FILE="/var/log/uctv-reg.log"

	log "Checking for 3PO registration status"

	# Loop for 15 iterations
	for i in {1..15}
	do
		# Check for heartbeatFreqInSecs which is 3PO log file
		if grep -q "heartbeatFreqInSecs" "$TPO_LOG_FILE"; then
			log "3PO registration successful"
			return
		fi

		# Wait for 5 second before the next iteration
		sleep 5
	done

	log "Failed to complete 3PO registration"
}

# Function to clean up transient files
service_cleanup() {
	# Cleanup the failed transient service
	#if systemctl status uctvUpgrade | grep "Active: failed"; then
		log "Cleaning up transient upgrade service at systemd"

		systemctl stop uctvUpgrade.service
		systemctl mask uctvUpgrade.service
		rm -f /etc/systemd/system/uctvUpgrade.service
		rm -f /run/systemd/transient/uctvUpgrade.service
		systemctl daemon-reload
		systemctl reset-failed
		systemctl unmask uctvUpgrade.service
	#fi

	#if [ -f /etc/init.d/uctvUpgrade ]; then
	#	log "Cleaning up transient upgrade service at init.d"
	#	service uctvUpgrade stop
	#	update-rc.d uctvUpgrade disable
	#	rm -f /etc/init.d/uctvUpgrade
	#	update-rc.d -f uctvUpgrade remove
	#	rm -f /var/run/uctvUpgrade.pid
	#	rm -f /var/lock/subsys/uctvUpgrade
	#fi

}

# Function to clean up temporary files
cleanup() {
	rm -rf "$UPG_DIR"
	rm -f /tmp/uctv_upgrade.sh

	service_cleanup

	log "Cleanup complete"
}

# Function to coordinate the upgrade process
uctv_upgrade() {

	log "++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	log "Upgrade Script started"

	# Setup signal traps
	setup_signal_traps

	# Remove stale backup directory, if any
	if [ -d "$UPG_DIR" ]; then
		rm -rf "$UPG_DIR"
	fi

	# Create upgrade and other directories
	create_upgrade_directories

	# Copy the status update module
	copy_status_update_module

	# Copy the agentCntlr_data file
	copy_agent_cntlr_data

	# Send started message to FM
	send_status "started"

	# Set global variables for image details
	set_image_details

	# Copy the new UCT-V image
	copy_image

	# Check for any ongoing upgrade
	check_ongoing_upgrade

	# Stop the UCT-V service
	stop_service

	# Backup configuration
	backup_config

	# Uninstall the old UCT-V service
	uninstall_service

	# Install the new UCT-V service
	install_service

	# Stop the service, to restore configuration
	stop_service

	# Restore configuration
	restore_config

	# Start the service
	start_service

	# Wait for service to start
	check_service_status

	# Wait 3PO regisrtation
	check_3po_reg_status

	# Send completed message to FM
	send_status "completed"

	# clean up
	cleanup

	log "Upgrade Script finished"
}

# Main function that processes the input argument
main() {
	case "$1" in
		"service_cleanup")
			service_cleanup
			;;
		"uctv_upgrade")
			uctv_upgrade
			;;
		*)
			log "Unknown arguement"
			;;
	esac
}

# Call the main function with arguments
main "$@"
