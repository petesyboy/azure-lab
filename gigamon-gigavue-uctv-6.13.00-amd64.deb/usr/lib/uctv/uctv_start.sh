#!/bin/bash
#
# Copyright (c) 2015 Gigamon Inc. All Rights Reserved.
#
#set -x
#export UCTV_DEBUG=5
GVTAP_AGENT_PROG_DIR=/usr/lib/uctv
GVTAP_AGENT_DATA_DIR=/var/lib/uctv
export GVTAP_AGENT_PROG_DIR=$GVTAP_AGENT_PROG_DIR
export GVTAP_AGENT_DATA_DIR=$GVTAP_AGENT_DATA_DIR
AGENT_VERSION="6.13.00"
PYTHON3=/usr/bin/python3
GVTAP_AGENT_SERVER=$GVTAP_AGENT_PROG_DIR/uctvd
GVTAP_AGENT_SERVER_CLASSIC=$GVTAP_AGENT_PROG_DIR/uctvd.classic
GVTAP_AGENT_CMD_CLASSIC=$GVTAP_AGENT_PROG_DIR/uctvl.classic
GVTAP_AGENT_LIB_CLASSIC=$GVTAP_AGENT_PROG_DIR/libuctvl-classic.so
GVTAP_AGENT_CMD=$GVTAP_AGENT_PROG_DIR/uctvl
GVTAP_CONF_FILE="/etc/uctv/uctv.conf"
USECONF_FALSE="/var/lib/uctv/bak/skipConf"

UCTV_ACM=/etc/uctv/certs/uctv-acm.json
UCTV_CLIENT_CA=/etc/uctv/certs/client-ca.crt
UCTV_CLIENT_CA_CHAIN=/etc/uctv/certs/client-ca-chain.crt
UCTV_ACM_ROOT_CA=/root/.step/authorities/uctv-cert/certs/root_ca.crt
UCTV_ACM_SRC_KEY=/etc/uctv/certs/uctv-key.conf
UCTV_ACM_SRC_CRT=/etc/uctv/certs/uctv-cert.conf
UCTV_ACM_SRC_ENC_KEY=/etc/uctv/certs/uctv-enc-key.conf
DST_ENC_KEY=/var/lib/uctv/uctv-enc.key
DST_KEY=/var/lib/uctv/uctv.key
DST_CRT=/var/lib/uctv/uctv.crt
DST_CHAIN_FILE="/var/lib/uctv/client-ca-chain.crt"
UCTV_ACM_PKI='/etc/uctv/uctVCertificateSpec'

CONF_FILE="/etc/ld.so.conf.d/uctv-ssl-lib64.conf"
LIB_PATH="/usr/lib/uctv/ssl-lib64"
UCTV_3PO_CONFIG=/etc/gigamon-cloud.conf

# G-vTAP iface permission flags
MIRROR_DST=1
MIRROR_SRC_INGRESS=2
MIRROR_SRC_EGRESS=4

#Generate Self Signed certificates to communicate with UCT-V Controller and CLI Commands
SELF_SIGNED_PATH=${GVTAP_AGENT_DATA_DIR}/certs/self_signed
TEMP_PATH=/tmp

KEY_FILE_NAME=uctv.key
KEY_ENC_FILE_NAME=uctv-enc.key
CRT_FILE_NAME=uctv.crt

# After upgrade encrypt plain keys
if [ -f "${SELF_SIGNED_PATH}/${KEY_FILE_NAME}" ]; then
	/usr/lib/uctv/uctv_cert encrypt ${SELF_SIGNED_PATH}/${KEY_FILE_NAME} ${SELF_SIGNED_PATH}/${KEY_ENC_FILE_NAME}
	chmod 600 ${SELF_SIGNED_PATH}/${KEY_ENC_FILE_NAME}
	rm -f ${SELF_SIGNED_PATH}/${KEY_FILE_NAME}
fi

if [ -f "${UCTV_ACM_SRC_KEY}" ]; then
	/usr/lib/uctv/uctv_cert encrypt ${UCTV_ACM_SRC_KEY} ${UCTV_ACM_SRC_ENC_KEY}
	chmod 600 ${UCTV_ACM_SRC_ENC_KEY}
	rm -f ${UCTV_ACM_SRC_KEY}

	if [ -f "${DST_KEY}" ]; then
		#Remove the plain key after UCT-V Upgrade
		nohup sh -c "sleep 300 && rm -f ${DST_KEY}" >/dev/null 2>&1 &

		cp ${UCTV_ACM_SRC_ENC_KEY} ${DST_ENC_KEY}
		chmod 600 ${DST_ENC_KEY}
	fi
fi

MAX_RETRY=3
# Check if Client key and certificate files already exist
if [ ! -f "${SELF_SIGNED_PATH}/${KEY_ENC_FILE_NAME}" ] || [ ! -f "${SELF_SIGNED_PATH}/${CRT_FILE_NAME}" ]; then
	${GVTAP_AGENT_PROG_DIR}/ssl_crt_key.sh "$TEMP_PATH" "$KEY_FILE_NAME" "$CRT_FILE_NAME"
	STATUS=$?
	if [ $STATUS -ne 0 ]; then
		echo "Unable to generate Self-signed certificate $KEY_FILE_NAME and $CRT_FILE_NAME"
		return 1
	fi
	/usr/lib/uctv/uctv_cert encrypt ${TEMP_PATH}/${KEY_FILE_NAME} ${SELF_SIGNED_PATH}/${KEY_ENC_FILE_NAME}
	rm -f ${TEMP_PATH}/${KEY_FILE_NAME}
	mv ${TEMP_PATH}/${CRT_FILE_NAME} ${SELF_SIGNED_PATH}/${CRT_FILE_NAME}
	chmod 600 ${SELF_SIGNED_PATH}/${KEY_ENC_FILE_NAME}
fi

# Check if libssl is linked
if ldd $GVTAP_AGENT_CMD_CLASSIC | grep -q 'libssl.so.3 => not found'; then
	echo "Creating $CONF_FILE and adding library path."
	echo "$LIB_PATH" | tee "$CONF_FILE" > /dev/null

	# Reload the library cache
	ldconfig
fi

skip_iface_config() {
	#Skip secure-tunnel-ring-buffer-memory-mb config
	if [[ $1 == *"secure-tunnel-ring-buffer-memory-mb"* ]]; then
		echo "skip secure tunnel ring buffer memory config"
		return 1
	fi

	#Skip secure-tunnel-ring-buffer-memory-mb config
	if [[ $1 == *"precryption-ring-buffer-memory-mb"* ]]; then
		echo "skip precryption ring buffer memory config"
		return 1
	fi

	#Skip secure-tunnel-cert-verify config
	if [[ $1 == *"secure-tunnel-cert-verify"* ]]; then
		echo "skip cert validation"
		return 1
	fi

	#Skip precryption-buffer-flush-timeout config
	if [[ $1 == *"precryption-buffer-flush-timeout"* ]]; then
		echo "skip precryption buffer flush timeout config"
		return 1
	fi

	#Skip precryption-path-mtu config
	if [[ $1 == *"precryption-path-mtu"* ]]; then
		echo "skip precryption path mtu config"
		return 1
	fi

    #Skip mirror-classic-vxlan-offload-off config
    if [[ $1 == *"mirror-classic-vxlan-offload-off"* ]]; then
        echo "skip mirror classic vxlan offload off config"
        return 1
    fi

	return 0
}

check_if_no_interface_conf(){
        if [ ! -e $GVTAP_CONF_FILE ]; then
		return 1
        fi
        while read -r LINE; do
		# Skip blank lines
		if [ ${#LINE} -eq 0 ]; then
			continue
		fi

		read -a WORD_ARRAY <<< $LINE

		# Skip commented lines
		if [[ ${WORD_ARRAY[0]:0:1} == "#" ]]; then
			continue
		fi

                # Skip if secure tunnel and precryption conf
		skip_iface_config "$LINE"
		if [[ $? -ne 0 ]]; then
			continue
		fi

                # If it's neither commented line nor secure tunnel and precryption conf
                return 0
        done < $GVTAP_CONF_FILE
        return 1
}

register_all_ifaces()
{
    PERMS=$(( $MIRROR_SRC_INGRESS | $MIRROR_SRC_EGRESS | $MIRROR_DST))
    interfaces=`ls /sys/class/net 2>/dev/null`
	List=($interfaces)
    for IFACE in "${List[@]}"; do
        case ${IFACE} in
        lo* | vxlan* | docker* | br-*  | veth*)
            # Skip these interfaces
            ;;
        *)
		    # Perform iface registration
		    LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 $GVTAP_AGENT_CMD iface-reg $IFACE $PERMS
		    if [ $? -ne 0 ]; then
	                echo "Error: Could not register interface: $IFACE"
	                return 1
		    fi
		    #FIXME: remove after devtest
            echo "Register $IFACE $PERMS completed"  >> /var/log/uctv.log
            ;;
        esac
	done
	return 0
}

register_ifaces_of_conf()
{
	while read -r LINE; do
		# Skip blank lines
		if [ ${#LINE} -eq 0 ]; then
			continue
		fi

		read -a WORD_ARRAY <<< $LINE

		# Skip commented lines
		if [[ ${WORD_ARRAY[0]:0:1} == "#" ]]; then
			continue
		fi

		skip_iface_config "$LINE"
		if [[ $? -ne 0 ]]; then
			continue
		fi

		LEN=${#WORD_ARRAY[*]}
		if [ $LEN -lt 2 ]; then
			echo "Error: Missing interface/permission in $GVTAP_CONF_FILE"
			return 1
		fi

		# Extract iface name
		IFACE=${WORD_ARRAY[0]}

		# Extract iface permissions
		PERMS=0
                if [[ $IFACE == *"lo"* ]]; then
                        PERMS=$(( $MIRROR_SRC_INGRESS | $MIRROR_SRC_EGRESS ))
                else
                        for (( OFF=1; OFF<=(($LEN - 1)); OFF++ )); do
                                PERM=${WORD_ARRAY[$OFF]}
                                case $PERM in
                                        "mirror-dst")
                                                (( PERMS=(( $PERMS | $MIRROR_DST )) ))
                                                ;;

                                        "mirror-src-ingress")
                                                (( PERMS=(( $PERMS | $MIRROR_SRC_INGRESS )) ))
                                                ;;

                                        "mirror-src-egress")
                                                (( PERMS=(( $PERMS | $MIRROR_SRC_EGRESS )) ))
                                                ;;

                                        *)
                                                echo "Error: Invalid permission in $GVTAP_CONF_FILE"
                                                return 1
                                                ;;
                                esac
                        done
                fi

		# Perform iface registration
		LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 $GVTAP_AGENT_CMD iface-reg $IFACE $PERMS
		if [ $? -ne 0 ]; then
			echo "Error: Could not register interface: $IFACE"
			return 1
		fi

	done < $GVTAP_CONF_FILE

	return 0
}

invalid_ifaces_check() {
    if [ -f /.dockerenv ]; then
            return 0
    fi

    if [ ! -e $GVTAP_CONF_FILE ]; then
            return 0
    fi

	iface_list=($(ip link show | awk -F: '$0 ~ /^[0-9]+:/ {print $2; getline}'))
	if [ $? -ne 0 ]; then
        echo "Error getting interface list."
        return -1
        fi
    	iface_list_lo_sub=($(ip addr show  | awk  '/scope host secondary lo:/ {print $NF; getline}'))

	user_iface_list=()
    while read -r LINE; do
        read -a WORD_ARRAY <<< "$LINE"
        # If the first character is '#' or the line is empty, skip to the next iteration
        if [[ "${WORD_ARRAY[0]:0:1}" == "#" || -z "$LINE" ]]; then
            continue
        fi
        skip_iface_config "$LINE"
        if [[ $? -ne 0 ]]; then
            continue
        fi
        # Append the iface name to user_iface_list
        user_iface_list+=("${WORD_ARRAY[0]}")
    done < $GVTAP_CONF_FILE
	if [ $? -ne 0 ]; then
        echo "Error reading $GVTAP_CONF_FILE"
        return -1
    fi
	# Compare the two lists and find if any ifaces are invalid
	invalid_ifaces=()
	for user_iface in "${user_iface_list[@]}"; do
		#echo "processing $user_iface ..."
		if [[ ! " ${iface_list[@]} " =~ " ${user_iface} " ]]; then
			#echo "$user_iface is not in ${iface_list[@]}..."
			if [[ " ${iface_list_lo_sub[@]} " =~ " ${user_iface} " ]]; then
				#echo "$user_iface is in valid alias lo ${iface_list_lo_sub[@]}..."
				if [[ " ${user_iface_list[@]} " =~ " lo " ]]; then
					#echo "lo is present in iface list. So we can skip $user_iface"
					invalid_ifaces_lo_skip+=("$user_iface")
				else
					#echo "$user_iface is NOT in valid alias lo ${iface_list_lo_sub[@]}..."
					invalid_ifaces_lo_sub+=("$user_iface")
				fi
			else
				invalid_ifaces+=("$user_iface")
			fi
		fi
	done

	for lo_iface in "${invalid_ifaces_lo_skip[@]}"; do
		message="Skipping Alias loopback interface ${lo_iface}"; echo "$message";  wall -n -t 1 "$message"
	done
	if [ ${#invalid_ifaces_lo_sub[@]} -ne 0 ]; then
		message="Error: Alias loopback interface(s) ${invalid_ifaces_lo_sub[@]} is added without Parent Loopback Interface"; echo "$message";  wall -n -t 1 "$message"
		message="Error: Please add lo parent interface instead of alias loopback interface"; echo "$message";  wall -n -t 1 "$message"
		message="Please change the configuration file $GVTAP_CONF_FILE to reference and register a valid interface."; echo "$message";  wall -n -t 1 "$message"
		message="Then restart the UCT-V service to apply the change."; echo "$message";  wall -n -t 1 "$message"
		return -1
	fi
	if [ ${#invalid_ifaces[@]} -ne 0 ]; then
		message="Error: The config file is trying to register following interface(s):"; echo "$message";  wall -n -t 1 "$message"
		message="${user_iface_list[@]}"; echo "$message";  wall -n -t 1 "$message"
		message="Below interface(s) does not exist on the system."; echo "$message";  wall -n -t 1 "$message"
		message="${invalid_ifaces[@]}"; echo "$message";  wall -n -t 1 "$message"
		message="Here is the list of interfaces detected:"; echo "$message";  wall -n -t 1 "$message"
		message="${iface_list[@]}"; echo "$message";  wall -n -t 1 "$message"
		message="Please change the configuration file $GVTAP_CONF_FILE to reference and register a valid interface."; echo "$message";  wall -n -t 1 "$message"
		message="Then restart the UCT-V service to apply the change."; echo "$message";  wall -n -t 1 "$message"
		return -1
	fi
	return 0
}

ipv6_regex='^([0-9a-f]{1,4}:){7}[0-9a-f]{1,4}$|^::([0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4}$|^[0-9a-f]{1,4}::([0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4}$|^([0-9a-f]{1,4}:){1,6}:$'
IPv4mappedIPv6_regex='^::ffff:(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}$'

uctv_is_ipv6_address()
{
        local ip_address_v6
        ip_address_v6=`echo $1| tr '[:upper:]' '[:lower:]'`
        if [[ $ip_address_v6 =~ $ipv6_regex ]]; then
                return 0
        elif [[ $ip_address_v6 =~ $IPv4mappedIPv6_regex ]]; then
                return 0
        fi
        return 1
}

uctv_get_ip_list()
{
        ifacelist=$(ip addr show | grep '^[0-9]' | awk '{print $2}' | cut -d ':' -f 1)
        iplist=()
        for interface in $ifacelist; do
                if [[ $interface == "lo"* ]] ; then
                        continue
                fi
                ip_address=$(ip addr show $interface | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -n 1)
                if [ -n "$ip_address" ]; then
                        if [[ "$ip_address" == 169.254.* ]]; then
                                : #echo "info: Skipping the Link local IP $ip_address"
                        else
                                iplist+=($ip_address)
                        fi
                fi
        done

        for interface in $ifacelist; do
                if [[ $interface == "lo"* ]] ; then
                        continue
                fi
                ip6_address=$(ip -6 addr show dev $interface | awk '/inet6 / && /global/ && !/deprecated/ && !/temporary/ {print $2}' | cut -d'/' -f 1)
                if [ -n "$ip6_address" ]; then
                        iplist+=($ip6_address)
                fi
        done
        echo "${iplist[@]}"
}

#config is also not present - return 3
#ACM cert path not exist (or) self-signed - create ACM cert - return 2
#cert start time and current time meets the renew hours - return 1
#good ACM cert - no operation - return 0
renew_acm_cert()
{

        if [ ! -f "$UCTV_ACM" ] ; then
                echo "config $UCTV_ACM file is missing"  >> /var/log/uctv.log
                return 3
        fi

        if [ ! -f "$DST_CRT" ] ; then
                echo "certificate $DST_CRT file is missing" >> /var/log/uctv.log
                return 2
        fi
	self_signed=$(/usr/lib/uctv/step certificate inspect $DST_CRT --format json | grep self_signed | cut -d':' -f2 | xargs)
        echo "self_signed:$self_signed" >> /var/log/uctv.log

        if [ "$self_signed" = "true" ] ; then
                return 2
        fi

        enddatestr=`/usr/lib/uctv/step certificate inspect $DST_CRT | grep "Not After" | cut -d':' -f2-4`
        enddate=$(date -d "$enddatestr" +%s)
        curdate=`date +%s`
        echo "enddate: $enddate curdate: $curdate" >> /var/log/uctv.log
        diff=$((($enddate-$curdate) / 3600))
        if [ $diff -le 0 ] ; then
                echo "certificate $DST_CRT file is invalid" >> /var/log/uctv.log
                return 2
        fi

        startdatestr=`/usr/lib/uctv/step certificate inspect $DST_CRT | grep "Not Before" | cut -d':' -f2-4`
        startdate=$(date -d "$startdatestr" +%s)
        echo "startdate: $startdate curdate: $curdate" >> /var/log/uctv.log
        diff=$((($curdate-$startdate) / 3600))
        expiry=1
        ACM_RENEWAL=`/usr/lib/uctv/uctvjq $UCTV_ACM -g renewal`
        echo "hours: $diff" >> /var/log/uctv.log
        if [ $diff -ge $ACM_RENEWAL ]; then
            echo "renew now" >> /var/log/uctv.log
            return 1
        fi

        echo "ACM cert is good to go" >> /var/log/uctv.log
        return 0
}

uctv_acm_bootstrap()
{
    ACM_IP=$(/usr/lib/uctv/uctvjq $UCTV_ACM -g raAddress 0)
    ACM_PORT=`/usr/lib/uctv/uctvjq $UCTV_ACM -g raPort`
    ACM_FINGERPRINT=`/usr/lib/uctv/uctvjq $UCTV_ACM -g fingerprint`
    ACM_ROOT="https://${ACM_IP}:${ACM_PORT}"
    if uctv_is_ipv6_address $ACM_IP; then
            ACM_ROOT="https://[${ACM_IP}]:${ACM_PORT}"
    fi
    rm -f /root/.step/authorities/uctv-cert/certs/root_ca.crt /root/.step/authorities/uctv-cert/config/defaults.json

    retry=0
    while [ $retry -lt $MAX_RETRY ]; do
        echo "/usr/lib/uctv/step ca bootstrap --context=uctv-cert --ca-url $ACM_ROOT --fingerprint $ACM_FINGERPRINT -f" >> /var/log/uctv.log
        /usr/lib/uctv/step ca bootstrap --context=uctv-cert --ca-url $ACM_ROOT --fingerprint $ACM_FINGERPRINT -f
        if [ $? -ne 0 ]; then
            echo "Error: Could not bootstrap ACM with $ACM_ROOT fingerprint $ACM_FINGERPRINT" >> /var/log/uctv.log
        else
            echo "Info: ACM bootstrapped with $ACM_ROOT fingerprint $ACM_FINGERPRINT" >> /var/log/uctv.log
            return 0 #Success
        fi

        ((retry++))
        if [ $retry -lt $MAX_RETRY ]; then
            sleep 3
        fi
    done

    return 1 #Failure
}

get_key_string()
{
        ACM_ALGO=`/usr/lib/uctv/uctvjq $UCTV_ACM -g algorithm`
        case $ACM_ALGO in
                RSA-2048|rsa-2048)
                        echo "--kty=RSA  --size=2048"
                        ;;
                RSA-3072|rsa-3072)
                        echo "--kty=RSA  --size=3072"
                        ;;
                RSA-4096|rsa-4096)
                        echo "--kty=RSA  --size=4096"
                        ;;
                RSA-8192|rsa-8192)
                        echo "--kty=RSA  --size=8192"
                        ;;
                ECDSA-256|ecdsa-256)
                        echo "--kty=EC  --curve=P-256"
                        ;;
                ECDSA-384|ecdsa-384)
                        echo "--kty=EC  --curve=P-384"
                        ;;
                ECDSA-521|ecdsa-521)
                        echo "--kty=EC  --curve=P-521"
                        ;;
                *)
                        echo "--kty=RSA  --size=2048"
                        ;;
        esac
}

uctv_upgrade_finish()
{
        if [ -f $UCTV_ACM_PKI ]
        then
            echo "PKI config identified..." >> /var/log/uctv.log
            UCM_RA=$(/usr/lib/uctv/uctvjq $UCTV_ACM_PKI -g raAddress)
            UCM_RAPORT=$(/usr/lib/uctv/uctvjq $UCTV_ACM_PKI -g raPort)
            UCM_FINGERPRINT=$(/usr/lib/uctv/uctvjq $UCTV_ACM_PKI -g fingerprint)
            UCM_ALGORITHM=$(/usr/lib/uctv/uctvjq $UCTV_ACM_PKI -g algorithm)
            UCM_VALIDITY=$(/usr/lib/uctv/uctvjq $UCTV_ACM_PKI -g validity)
            UCM_RENEWAL=$(/usr/lib/uctv/uctvjq $UCTV_ACM_PKI -g renewal)
            UCM_CA=$(/usr/lib/uctv/uctvjq $UCTV_ACM_PKI -g clientCa)
            acm="{\"raAddress\": [\"$UCM_RA\"], \"raPort\": \"$UCM_RAPORT\", \"fingerprint\": \"$UCM_FINGERPRINT\", \"algorithm\": \"$UCM_ALGORITHM\", \"validity\": \"$UCM_VALIDITY\", \"renewal\": \"$UCM_RENEWAL\"}"
            mkdir -p /etc/uctv/certs
            echo "${acm}" > ${UCTV_ACM}
            echo "${UCM_CA}" > ${UCTV_CLIENT_CA}
            echo "${UCM_CA}" > ${UCTV_CLIENT_CA_CHAIN}
            rm $UCTV_ACM_PKI
            uctv_init_acm_certs

            #Copy CA certificate
            if [ ! -f "$DST_CHAIN_FILE" ] && [ -f "$UCTV_CLIENT_CA_CHAIN" ]; then
                    cp ${UCTV_CLIENT_CA_CHAIN} ${DST_CHAIN_FILE}
            fi
        fi
}
 
uctv_init_acm_certs() 
{
    cert_created=false
    if [ -f "$UCTV_ACM" ] && [ -f "$UCTV_CLIENT_CA_CHAIN" ];
    then
            echo "Info: Using ACM infra" >> /var/log/uctv.log
    	    ACM_IP=$(/usr/lib/uctv/uctvjq $UCTV_ACM -g raAddress 0)
            ACM_PORT=`/usr/lib/uctv/uctvjq $UCTV_ACM -g raPort`
            ACM_FINGERPRINT=`/usr/lib/uctv/uctvjq $UCTV_ACM -g fingerprint`
            ACM_ROOT="https://${ACM_IP}:${ACM_PORT}"
            if uctv_is_ipv6_address $ACM_IP; then
                ACM_ROOT="https://[${ACM_IP}]:${ACM_PORT}"
            fi
            uctv_ip_list=($(uctv_get_ip_list))
            echo "Printing uctv ip list: ${uctv_ip_list[@]}"  >> /var/log/uctv.log
            if [ -n "$ACM_ROOT" ] && [ -n "$ACM_FINGERPRINT" ] && [ ${#uctv_ip_list[@]} -gt 0 ]; then
                    renew_acm_cert
                    renewnow=$?
                    echo "renewnow: $renewnow" >> /var/log/uctv.log
                    if [ $renewnow -eq 1 ]; then
                            uctv_acm_bootstrap
                            bootstrap_status=$?
                            if [ $bootstrap_status -ne 0 ]; then
                               return 0
                            fi
                            retry=0
                            while [ $retry -lt $MAX_RETRY ]; do
                                echo "certificate renew" >> /var/log/uctv.log
                                /usr/lib/uctv/uctv_cert renew >> /var/log/uctv.log
                                if [ $? -ne 0 ]; then
                                    echo "Error: Failed to renew the UCTv certificate" >> /var/log/uctv.log
                                else
                                    echo "Info: Renewed the UCTv certificate" >> /var/log/uctv.log
                                    cert_created=true
                                    break
                                fi
                                ((retry++))
                                if [ $retry -lt $MAX_RETRY ]; then
                                    sleep 3
                                fi
                            done

                            if [ $retry -eq $MAX_RETRY ]; then
                               #Since renew got failed, trying to re-issue
                               echo "Info: Re-issuing the UCTv certificate" >> /var/log/uctv.log
                               renewnow=2
                            fi
                    fi

                    if [ $renewnow -eq 2 ]; then
                            uctv_acm_bootstrap
                            bootstrap_status=$?
                            if [ $bootstrap_status -ne 0 ]; then
                               return 0
                            fi
                            echo "/usr/lib/uctv/step certificate install $UCTV_ACM_ROOT_CA" >> /var/log/uctv.log
                            /usr/lib/uctv/step certificate install $UCTV_ACM_ROOT_CA >> /var/log/uctv.log
                            if [ $? -ne 0 ]; then
                                    echo "Error: Could not install ACM root certificate" >> /var/log/uctv.log
                            else
                                    echo "Info: Installed ACM root certificate" >> /var/log/uctv.log
                            fi 
                            rm -f $UCTV_ACM_SRC_CRT $UCTV_ACM_SRC_ENC_KEY
                            ACM_VALIDITY=`/usr/lib/uctv/uctvjq $UCTV_ACM -g validity`
                            if [ -z "$ACM_VALIDITY" ]; then
                                    ACM_VALIDITY=2160
                            fi
                            ACM_VALIDITY_HOURS=$(($ACM_VALIDITY))
                            TIME_VALID="${ACM_VALIDITY_HOURS}h"
             			    UCTV_KEY_STRING=$(get_key_string)
                            echo "Time: $ACM_VALIDITY_HOURS $TIME_VALID UCTV_KEY_STRING:$UCTV_KEY_STRING" >> /var/log/uctv.log

                            retry=0
                            while [ $retry -lt $MAX_RETRY ]; do
                                for ip in "${uctv_ip_list[@]}"; do
                                    echo "certificate issue: $ip valid for ${ACM_VALIDITY_HOURS} with $UCTV_KEY_STRING " >> /var/log/uctv.log
                                    /usr/lib/uctv/uctv_cert issue $ip $UCTV_KEY_STRING ${ACM_VALIDITY_HOURS} >> /var/log/uctv.log
                                    if [ $? -ne 0 ]; then
                                        echo "Error: Could not generate ACM based UCTv certificate" >> /var/log/uctv.log
                                    else
                                        echo "Info: Generated ACM based UCTv certificate" >> /var/log/uctv.log
                                        cert_created=true
                                        break
                                    fi
                                done
                                if [ "$cert_created" = "true" ]; then
                                    break
                                fi
                                ((retry++))
                                if [ $retry -lt $MAX_RETRY ]; then
                                    sleep 3
                                fi
                            done
                    fi

                    if [ $renewnow -ne 1 ] && [ $renewnow -ne 2 ]; then
                            cert_created=false
                            echo "Info: Valid ACM certificate" >> /var/log/uctv.log
                    fi
            fi
    fi
    
    if [ "$cert_created" = true ]; then
            cp ${UCTV_ACM_SRC_ENC_KEY} ${DST_ENC_KEY}
            cp ${UCTV_ACM_SRC_CRT} ${DST_CRT}
            cp ${UCTV_CLIENT_CA_CHAIN} ${DST_CHAIN_FILE}
    fi
}

if [ -f "$GVTAP_AGENT_SERVER_CLASSIC" ]; then
	LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 ldd ${GVTAP_AGENT_SERVER} 2>&1 | grep "GLIBC.*not found" > /dev/null
	if [ $? -eq 0 ]; then
		cp ${GVTAP_AGENT_SERVER_CLASSIC} ${GVTAP_AGENT_SERVER}
		cp ${GVTAP_AGENT_CMD_CLASSIC} ${GVTAP_AGENT_CMD}
		#echo "Info: Classic GvTap Agent binary is used"
	else
		#rm ${GVTAP_AGENT_SERVER_CLASSIC}
		#rm ${GVTAP_AGENT_CMD_CLASSIC}
		#rm ${GVTAP_AGENT_LIB_CLASSIC}
		#echo -n "Info: NG GvTap Agent binary is used"
		#We need old binary files as well, do not delete them!
		echo -n ""
	fi
fi

# Proceed iff G-vTAP agent is not running
PID=`pidof $GVTAP_AGENT_SERVER`
if [ $PID > 0 ]; then
	echo "Error: UCT-V is (already) running"
	exit 1
fi
#Check for invalid ifaces
invalid_ifaces_check 
if [ $? -ne 0 ]; then
	exit 1
fi

# Reset G-vTAP agent
LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 $GVTAP_AGENT_CMD uctv-ctl --reset
if [ $? -ne 0 ]; then
	echo "Error: UCT-V reset failure"
	exit 1
fi

uctv_upgrade_finish

#Get PKI
AGENT_TYPE="uctV"

if [ -f ${UCTV_3PO_CONFIG} ]; then
	grep -q "Registration" ${UCTV_3PO_CONFIG} && grep "token" ${UCTV_3PO_CONFIG} > /dev/null
	if [ $? -eq 0 ]; then
		grep "groupName\|subGroupName\|remoteIP\|remoteAddress" ${UCTV_3PO_CONFIG} > /dev/null
		if [ $? -eq 0 ]; then
			LD_LIBRARY_PATH=/usr/lib/uctv/lib /usr/lib/uctv/uctv_getpki -v ${AGENT_VERSION} -t ${AGENT_TYPE}
			if [ $? -ne 0 ]; then
				echo "Error: UCTv agent get-pki failed. Please check and correct the gigamon-cloud.conf"
				exit 1
			fi
		fi
	fi
fi
uctv_init_acm_certs

# Start G-vTAP agent
LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 $GVTAP_AGENT_CMD uctv-ctl --start
if [ $? -ne 0 ]; then
	echo "Error: UCT-V start failure"
	exit 1
else
	PID=$(ps aux | awk '! /awk/ && /uctvd/ {print $2; exit}')
	if [ $PID > 0 ]; then
		echo $PID > /var/run/uctv.pid
	fi
fi

# Wait for G-vTAP agent to become ready
sleep 10
MTLS_PORT=9902
RPC=`ss -tnlp | grep LISTEN | grep :$MTLS_PORT`
for i in {1..25}; do
	if [ ! -z "$RPC" ]; then
		break
	fi
	sleep 10
	RPC=`ss -tnlp | grep LISTEN | grep :$MTLS_PORT`
done

# Register ifaces with G-vTAP agent

#In shell scripting, 0 is true and 1 is false
#Here, 0 means interface config present, 1 means no interface config
if [ -e $GVTAP_CONF_FILE ] && check_if_no_interface_conf && [ ! -e $USECONF_FALSE ]; then
        echo "Registering ifaces with conf file" >> /var/log/uctv.log
        register_ifaces_of_conf
else
        echo "Registering all the ifaces" >> /var/log/uctv.log
        register_all_ifaces
fi
if [ $? -ne 0 ]; then
	echo "Error: UCT-V interface registration failure"
	exit 1
fi

# Reset G-vTAP agent
LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 $GVTAP_AGENT_CMD agent-reload
if [ $? -ne 0 ]; then
        echo "Error: UCT-V reload failure"
        exit 1
fi
if grep -q '^RemainAfterExit' /etc/systemd/system/uctv.service; then
    sed -i '/^RemainAfterExit/d' /etc/systemd/system/uctv.service
    systemctl daemon-reload
fi
exit 0
