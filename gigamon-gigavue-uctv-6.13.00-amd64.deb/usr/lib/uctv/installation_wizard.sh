#!/bin/bash
#
# Copyright 2024 Gigamon Inc. All rights reserved.
#

readonly tmp="/var/log/uctv-installation.log"
readonly info="/etc/os-release"

# Define ports as "<Port>|<Protocol>|<Direction>|<Name>"
inbound_ports=(
    "9902|tcp|Inbound|GigaVUE UCT-V (Management)"
    "8301|tcp|Inbound|GigaVUE UCT-V (http01_challenge_port)"
)
outbound_ports=(
    "9900|tcp|Outbound|GigaVUE UCT-V (Traffic Health and Statistics)"
    "8300|tcp|Outbound|GigaVUE UCT-V (pki_ra_port)"
    "8892|tcp|Outbound|GigaVUE UCT-V (for 3PO Registration)"
    "4789|udp|Outbound|GigaVUE UCT-V (for Mirror Data on VXLAN)"
    "11443|tcp|Outbound|GigaVUE UCT-V (for Mirror Data on Secure Tunnels)"
    "47|gre|Outbound|GigaVUE UCT-V (for Mirror Data on L2GRE)"
)
missing_ports=()
missing_ufw_ports=()
readonly firewall_ports=( "${inbound_ports[@]}" "${outbound_ports[@]}" )
fw_ready=0
fw_running=0
ufw_running=0
fwd_configured=0
ufw_configured=0
auto_yes=false
Ext=""
kernel_version=$(uname -r)
major_kversion=$(echo $kernel_version | cut -d '.' -f 1)
minor_kversion=$(echo $kernel_version | cut -d '.' -f 2)

##Helper Function to check Kernel version, returns 0 if installing tc-rules is not needed
kern_version_cmp() {
    local supported_major_version=4
    local supported_minor_version=18

    if [ $major_kversion -gt $supported_major_version ]; then
        return 0
    elif [ $major_kversion -lt $supported_major_version ]; then
        return 1
    else
        if [ $minor_kversion -ge $supported_minor_version ]; then
            return 0
        else
            return 1
        fi
    fi
}

#In order to give option to user to install packages if they want to, as well as add option to skip prompts if user pass additional arguments -y
prompt_user() {
	local fun_name="prompt_user"
	LogsWriteShow $fun_name "$1 (y/N)"
    if $auto_yes; then
	LogsWriteShow $fun_name "y" "skip-terminal"
        return 0
    else
        read answer
		LogsWriteShow $fun_name "$answer" "skip-terminal"
        if [ "$answer" = "y" ]; then
            return 0
        else
            return 1
        fi
    fi
}

initialize_logs() {
    #Log file can be used by both daemon service and user
    if [ ! -f "$tmp" ]; then
        touch "$tmp"
		chmod 666 "$tmp"
    fi
}

#Log function to capture all the echo output in log file as well
LogsWriteShow() {
	local function_name="$1"
	local message="$2"
	local option="$3"

	if [ -z "$message" ]; then
		return
	fi

	if [ "$option" != "skip-terminal" ]; then
		echo "$message"
	fi

	local timestamp
	timestamp=$(date +"%Y-%m-%d %H:%M:%S")
	local log_entry="${timestamp} : ${function_name}: ${message}"
	echo "$log_entry" >> "$tmp"
}

#Helper function to write the standard errors in the same format as other logs
LogStderr() {
	local function_name="$1"
	while IFS= read -r line; do
		LogsWriteShow "$function_name" "$line"
	done
}

##
## Check if required package are installed
##
function CheckPackages() {
	local fun_name="CheckPackages"
	LogsWriteShow $fun_name "Checking dependencies... All are good"
    	return 0
}

#Check required python package for agent post-installation
function CheckPackagesPostinst() {
	local fun_name="CheckPackagesPostinst"
	LogsWriteShow $fun_name "Checking dependencies... All are good"
	return 0
}

##
## Check if firewall installed, runnning, configured for UCTV
##
function CheckFirewall() {
	local fun_name="CheckFirewall"
	LogsWriteShow $fun_name "Checking firewall status..."

	# Check if firewall-cmd is installed
	fw=`sudo firewall-cmd -V 2> >(LogStderr "$fun_name")`
	if [ $? -eq 0 ]; then
		LogsWriteShow $fun_name " - Firewall is installed, version: $fw"

		# Check if the firewall is running
		fw=$(sudo firewall-cmd --list-all)
		if [ $? -eq 0 ]; then
			LogsWriteShow $fun_name " - Firewall is running"
			local all_ports_exist=1

			# Check each port
			for idx in "${!firewall_ports[@]}"; do
				record="${firewall_ports[idx]}"
				IFS="|" read -r port proto direction name <<< "$record"
				origin=$([ "$direction" = "Inbound" ] && echo "source" || echo "destination")

				# Check if the port is added for IPv4
				if [ "$port" = "47" ]; then
					sudo firewall-cmd --permanent --query-rich-rule="rule family=\"ipv4\" $origin address=\"0.0.0.0/0\" protocol value=\"${proto,,}\" accept" > /dev/null
				else
					sudo firewall-cmd --permanent --list-rich-rules | grep -Fq "rule family=\"ipv4\" $origin address=\"0.0.0.0/0\" port port=\"$port\" protocol=\"${proto,,}\" accept" > /dev/null
				fi

				if [ $? -ne 0 ]; then
					if [ "$port" = "47" ]; then
						LogsWriteShow $fun_name " - Firewall requires permanent IPv4/IPv6 policy for $proto $direction $name"
					else
						LogsWriteShow $fun_name " - Firewall requires permanent IPv4/IPv6 policy for $port $proto $direction $name"
					fi
					missing_ports+=("$idx")
					all_ports_exist=0
					continue
				fi

				# Check if the port is added for IPv6
				if [ "$port" = "47" ]; then
					sudo firewall-cmd --permanent --query-rich-rule="rule family=\"ipv6\" $origin address=\"::/0\" protocol value=\"${proto,,}\" accept" > /dev/null
				else
					sudo firewall-cmd --permanent --list-rich-rules | grep -Fq "rule family=\"ipv6\" $origin address=\"::/0\" port port=\"$port\" protocol=\"${proto,,}\" accept" > /dev/null
				fi

				if [ $? -ne 0 ]; then
					if [ "$port" = "47" ]; then
						LogsWriteShow $fun_name " - Firewall requires permanent IPv4/IPv6 policy for $proto $direction $name"
					else
						LogsWriteShow $fun_name " - Firewall requires permanent IPv4/IPv6 policy for $port $proto $direction $name"
					fi
					missing_ports+=("$idx")
					all_ports_exist=0
					continue
				fi

				if [ "$port" = "47" ]; then
					LogsWriteShow $fun_name " - Policy exists for $proto $direction $name in permanent config"
				else
					LogsWriteShow $fun_name " - Policy exists for $port $proto $direction $name in permanent config"
				fi
			done

			# Set fw_ready if all ports exist in both running and permanent configs
			if [ $all_ports_exist -eq 1 ]; then
				fw_ready=1
				fwd_configured=1
			fi
		else
			LogsWriteShow $fun_name " - Firewall is not running"
			fw_running=1
			fw_ready=1
		fi
	else
		LogsWriteShow $fun_name " - Firewall is not installed"
		fw_running=1
		fw_ready=1
	fi
}

function CheckUFW() {
    local fun_name="CheckUFW"

    # Check if UFW is installed
    if ! sudo ufw version &> /dev/null; then
        LogsWriteShow $fun_name " - Uncomplicated Firewall (UFW) is not installed"
		ufw_running=1
        return 1
    else
        ufw_version=$(sudo ufw version | grep 'ufw' | awk '{print $2}')
        LogsWriteShow $fun_name " - Uncomplicated Firewall (UFW) is installed, version: $ufw_version"
    fi

    # Check if UFW is running
    if ! sudo ufw status | grep -q "Status: active"; then
        LogsWriteShow $fun_name " - Uncomplicated Firewall (UFW) is not running"
		ufw_running=1
        return 1
    fi

    local all_ports_exist=1
    for idx in "${!firewall_ports[@]}"; do
        record="${firewall_ports[idx]}"
        IFS="|" read -r port proto direction name <<< "$record"
        tag=$([ "$direction" = "Inbound" ] && echo "IN" || echo "OUT")


        if [ "$port" = "47" ]; then
            sudo ufw status verbose | grep -Eq "${proto}.*${tag}"
        else
            sudo ufw status verbose | grep -Eq "${port}/${proto}.*${tag}"
        fi

        if [ $? -eq 0 ]; then
            if [ "$port" = "47" ]; then
                LogsWriteShow $fun_name " - $proto $direction is already configured in Uncomplicated Firewall (UFW)"
            else
                LogsWriteShow $fun_name " - $port $proto $direction is already configured in Uncomplicated Firewall (UFW)"
            fi
        else
            if [ "$port" = "47" ]; then
                LogsWriteShow $fun_name " - $proto $direction is missing in UFW configuration"
            else
                LogsWriteShow $fun_name " - $port $proto $direction is missing in UFW configuration"
            fi
            missing_ufw_ports+=("$idx")
            all_ports_exist=0
        fi
    done

    if [ $all_ports_exist -eq 1 ]; then
        ufw_configured=1
		return 1
    fi

    return 0
}

##
## Detect Linux distro and set default package extension
##
function SetExt() {
	local fun_name="SetExt"
    LogsWriteShow $fun_name "Checking the OS details..."
    test -r $info
    if [ $? -ne 0 ]; then
        LogsWriteShow $fun_name " - Can't read $info. Something is very wrong, exiting"
        return 1;
    fi 
    source $info
    LogsWriteShow $fun_name " - Host OS is ${PRETTY_NAME}"

    case ${ID} in
    "ubuntu" | "debian")
        Ext="deb"
        return 0;
        ;;
    "centos" | "rhel" | "fedora" | "rocky" | "suse" | "ol" | "amzn")
        Ext="rpm"
        return 0;
        ;;
    *)
        # unsupported
        LogsWriteShow $fun_name " - Unsupported OS"
        return 1;
        ;;
    esac    
}

##
## Add UCT-V specific firewall rule to running and permanent configs
##
function ConfigureFirewall() {
	local fun_name="ConfigureFirewall"
	status=0

	for idx in "${missing_ports[@]}"; do
		record="${firewall_ports[idx]}"
		IFS="|" read -r port proto direction name <<< "$record"

		if [ "$port" = "47" ]; then
			message="Do you want to add active zone policy: $proto $direction $name"
		else
			message="Do you want to add active zone policy: $port $proto $direction $name"
		fi

		if ! prompt_user "$message"; then
			case "$port" in
				9902|8300|8301|9900) status=1 ;;
			esac

			if [ "$port" = "47" ]; then
				LogsWriteShow $fun_name " - User declined to add policy for $proto $direction $name"
			else
				LogsWriteShow $fun_name " - User declined to add policy for $port $proto $direction $name"
			fi

			continue
		fi

		if [ "$direction" = "Inbound" ]; then
			origin="source"
			v4addr="source address='0.0.0.0/0'"
			v6addr="source address='::/0'   "
		else
			origin="destination"
			v4addr="destination address='0.0.0.0/0'"
			v6addr="destination address='::/0'   "
		fi

		# Add IPv4 firewall rules
		if [ "$port" = "47" ]; then
			sudo firewall-cmd --permanent --add-rich-rule="rule family='ipv4' $v4addr protocol value='${proto,,}' accept" > /dev/null 2> >(LogStderr "$fun_name")
		else
			sudo firewall-cmd --permanent --add-rich-rule="rule family='ipv4' $v4addr port port='$port' protocol='${proto,,}' accept" > /dev/null 2> >(LogStderr "$fun_name")
		fi

		if [ $? -ne 0 ]; then
			if [ "$port" = "47" ]; then
				LogsWriteShow $fun_name " - Failed to add IPv4 active zone policy for $proto $direction $name"
			else
				LogsWriteShow $fun_name " - Failed to add IPv4 active zone policy for $port $proto $direction $name"
			fi
			status=1
			continue
		fi

		# Check if the port is added for IPv4
		if [ "$port" = "47" ]; then
			sudo firewall-cmd --permanent --query-rich-rule="rule family=\"ipv4\" $origin address=\"0.0.0.0/0\" protocol value=\"${proto,,}\" accept" > /dev/null
		else
			sudo firewall-cmd --permanent --list-rich-rules | grep -Fq "rule family=\"ipv4\" $origin address=\"0.0.0.0/0\" port port=\"$port\" protocol=\"${proto,,}\" accept" > /dev/null
		fi

		if [ $? -ne 0 ]; then
			if [ "$port" = "47" ]; then
				LogsWriteShow $fun_name " - Failed to verify $proto $direction $name for IPv4"
			else
				LogsWriteShow $fun_name " - Failed to verify $port $proto $direction $name for IPv4"
			fi
			status=1
			continue
		fi

                # Add IPv6 firewall rules
		if [ "$port" = "47" ]; then
			sudo firewall-cmd --permanent --add-rich-rule="rule family='ipv6' $v6addr protocol value='${proto,,}' accept" > /dev/null 2> >(LogStderr "$fun_name")
		else
			sudo firewall-cmd --permanent --add-rich-rule="rule family='ipv6' $v6addr port port='$port' protocol='${proto,,}' accept" > /dev/null 2> >(LogStderr "$fun_name")
		fi

		if [ $? -ne 0 ]; then
			if [ "$port" = "47" ]; then
				LogsWriteShow $fun_name " - Failed to add IPv6 active zone policy for $proto $direction $name"
			else
				LogsWriteShow $fun_name " - Failed to add IPv6 active zone policy for $port $proto $direction $name"
			fi
                        status=1
                        continue
                fi

                # Check if the port is added for IPv6
		if [ "$port" = "47" ]; then
			sudo firewall-cmd --permanent --query-rich-rule="rule family=\"ipv6\" $origin address=\"::/0\" protocol value=\"${proto,,}\" accept" > /dev/null
		else
			sudo firewall-cmd --permanent --list-rich-rules | grep -Fq "rule family=\"ipv6\" $origin address=\"::/0\" port port=\"$port\" protocol=\"${proto,,}\" accept" > /dev/null
		fi

		if [ $? -ne 0 ]; then
			if [ "$port" = "47" ]; then
				LogsWriteShow $fun_name " - Failed to verify $proto $direction $name for IPv6"
			else
				LogsWriteShow $fun_name " - Failed to verify $port $proto $direction $name for IPv6"
			fi
                        status=1
                        continue
                fi

		if [ "$port" = "47" ]; then
			LogsWriteShow $fun_name " - Firewall policy added for $proto $direction $name"
		else
			LogsWriteShow $fun_name " - Firewall policy added for $port $proto $direction $name"
		fi
	done

	# If all mandatory ports were successfully added, set fw_ready to 1
	if [ $status -eq 0 ]; then
		fw_ready=1
	fi

	sudo firewall-cmd --reload > /dev/null 2> >(LogStderr "$fun_name")
	return $status
}

function ConfigureUFW() {
	local fun_name="ConfigureUFW"
	status=0 

	for idx in "${missing_ufw_ports[@]}"; do
		record="${firewall_ports[idx]}"
		IFS="|" read -r port proto direction name <<< "$record"

		if [ "$port" = "47" ]; then
			message="Do you want to add active zone policy: $proto $direction $name"
		else
			message="Do you want to add active zone policy: $port $proto $direction $name"
		fi

		if ! prompt_user "$message"; then
			case "$port" in
				9902|8300|8301|9900) status=1 ;;
			esac
			if [ "$port" = "47" ]; then
				LogsWriteShow $fun_name " - User declined to add policy: $proto $direction for $name."
			else
				LogsWriteShow $fun_name " - User declined to add policy: $port $proto $direction for $name."
			fi
			continue
		fi

		# Add port to UFW rules
		if [ "$direction" = "Inbound" ]; then
			sudo ufw allow proto "$proto" from any to any port "$port" comment "$name" > /dev/null 2> >(LogStderr "$fun_name")
		else
			if [ "$port" = "47" ]; then
				sudo ufw allow out proto "$proto" from any to any comment "$name" > /dev/null 2> >(LogStderr "$fun_name")
			else
				sudo ufw allow out proto "$proto" from any to any port "$port" comment "$name" > /dev/null 2> >(LogStderr "$fun_name")
			fi
		fi

		if [ $? -eq 0 ]; then
			if [ "$port" = "47" ]; then
				LogsWriteShow $fun_name "$proto $direction for $name added to ufw"
			else
				LogsWriteShow $fun_name "$port $proto $direction for $name added to ufw"
			fi
		else
			if [ "$port" = "47" ]; then
				LogsWriteShow $fun_name "Failed to add $proto $direction for $name to ufw"
			else
				LogsWriteShow $fun_name "Failed to add $port $proto $direction for $name to ufw"
			fi
			status=1
		fi
	done
	sudo ufw reload > /dev/null 2> >(LogStderr "$fun_name")

	return $status
}

##
## Install Dependencies
##
function PkgInstall() {
	local fun_name="PkgInstall"
    ping -c 1 8.8.8.8 > /dev/null 2>&1
    if [ $? -ne 0 ]; then
    LogsWriteShow $fun_name "No network connectivity. Installation aborted."
    return 0
    fi
	#If user wants to skip prompts
	if [ "$2" == "-y" ]; then
		auto_yes=true
	fi

	CheckPackages
	if [ $? -eq 0 ]; then
		LogsWriteShow $fun_name "Nothing to install, wont restart the service."
		return 0
	fi

	CheckFirewall

	CheckUFW

	if [ $fw_running -eq 0 ] && [ $fwd_configured -eq 0 ]; then
		LogsWriteShow $fun_name "Firewall is not configured, won't restart the service"
		return 0
	fi

	if [ $ufw_running -eq 0 ] && [ $ufw_configured -eq 0 ]; then
		LogsWriteShow $fun_name "Uncomplicated Firewall (UFW) is not configured, won't restart the service"
		return 0
	fi

    Service="uctv"
    LogsWriteShow $fun_name "Installation has been completed successfully."
	LogsWriteShow $fun_name "Restarting the $Service service..."
	LogsWriteShow $fun_name " - stopping service"
    temp=`sudo systemctl stop $Service`
	LogsWriteShow $fun_name " - letting the dust settle"
	temp=`sleep 10`
	LogsWriteShow $fun_name " - starting service"
    temp=`sudo systemctl start $Service`
    if [ $? -eq 0 ]; then
        LogsWriteShow $fun_name " - $Service is running"
        return 0
    else
        LogsWriteShow $fun_name "ERROR: $Service is not running"
        return 1
    fi

    return 0
}

##
## Configure UCT-V Software automatically, based on default assumptions
##
function DoConfig() {
	local fun_name="DoConfig"
    LogsWriteShow $fun_name "Checking Installation..."
    Service="uctv"
    local RESTART_SVC=$3
	local RESTART_SVC_FW=false
	local is_agent=false
	local conf_change=false
	local upgrade_service="upgrade.service"
	if [ "$2" == "agent" ]; then
        is_agent=true
    fi
	#If user wants to skip firewall prompts
	if [ "$2" == "-y" ]; then
		auto_yes=true
	fi
    if [ "$Ext" == "rpm" ]; then
        temp=`rpm -q $Service 2>>/dev/null`
    else 
        temp=`dpkg -l $Service 2>>/dev/null`
    fi
    if [ $? -ne 0 ]; then    
        LogsWriteShow $fun_name "ERROR $Service is not installed. Install first before configuring"
        return 1
    fi
    ConfPath="/etc/uctv"
    if [ ! -d $ConfPath ];then
        LogsWriteShow $fun_name "ERROR: $ConfPath folder does not exist. Is $Service installed?"
        return 1
    fi
    ConfName="uctv.conf"
    ConfFile="$ConfPath/$ConfName"
	ConfFileLocal="/tmp/uctv.conf"
    TpoPath="/etc"
    TpoName="gigamon-cloud.conf"
    TpoFile="$TpoPath/$TpoName"
	TpoFileLocal="/tmp/gigamon-cloud.conf" 
    
	# Copy additional config file for third party orchestration if it exists
	if [ -f $TpoFileLocal ]; then
		if [ ! -f $TpoFile ]; then
			sudo cp -f $TpoFileLocal $TpoPath
			LogsWriteShow $fun_name " - Using local conf file $TpoFileLocal for third party orchestration"
			conf_change=true
		else
			LogsWriteShow $fun_name "################################################################################"
			LogsWriteShow $fun_name "Warning! Found an existing configured file at $TpoFile. Wont change any configuration!"
		fi
	fi

    # Use locally supplied config file if it exists
    if [ -f $ConfFileLocal ]; then
		if [ ! -f $ConfFile ] || ([ -f $ConfFile ] && ! grep -q '^[^#]' "$ConfFile"); then 
			sudo cp -f $ConfFileLocal $ConfPath
			LogsWriteShow $fun_name " - Using local conf file $ConfFileLocal"
			conf_change=true
		else
			LogsWriteShow $fun_name "################################################################################"
			LogsWriteShow $fun_name "Warning! Found an existing configured file at $ConfFile. Wont change any configuration!"
		fi
    else
		if [ ! -f $ConfFile ] || ([ -f $ConfFile ] && ! grep -q '^[^#]' "$ConfFile"); then 
			LogsWriteShow $fun_name " - Creating new main config file"
			conf_change=true
			Interfaces=`ls /sys/class/net 2>/dev/null`
			List=($Interfaces)

			# Create the new main .conf file
			LogsWriteShow $fun_name " - Writing configuration to $ConfFile"

			LogsWriteShow $fun_name "################################################################################" | sudo tee $ConfFile
			LogsWriteShow $fun_name "# All ingress and egress traffic for interfaces will be mirrored" | sudo tee -a $ConfFile
			for Item in "${List[@]}"
			do
				case ${Item} in
				lo* | vxlan* | docker* | br-*  | veth*)
					# Skip these interfaces
					;;
				enP*s*)
					driver=$(ethtool -i "$Item" 2>/dev/null | grep -i driver | awk '{print $2}')
					if [[ "$driver" == "mlx5_core" || "$driver" == "mlx4_core" || "$driver" == "mana" ]]; then
						LogsWriteShow $fun_name "The interface $Item is Accelerated Networking Interface. So, not included in the uctv.conf file"
					fi
					;;
				*)
					echo "$Item mirror-src-ingress mirror-src-egress mirror-dst" >> $ConfFile
					LogsWriteShow $fun_name "$Item mirror-src-ingress mirror-src-egress mirror-dst"
					;;
					  
				esac    
			done
			echo "################################################################################" >> $ConfFile
			LogsWriteShow $fun_name "################################################################################"
			sudo chmod 644 $ConfFile
		else
			LogsWriteShow $fun_name "################################################################################"
			LogsWriteShow $fun_name "Warning! Found an existing configured file at $ConfFile. Wont change any configuration!"
		fi
    fi


	CheckFirewall
	if [ $fw_ready -eq 0 ]; then
		if [ "$is_agent" == false ]; then
			ConfigureFirewall
			if [ $? -ne 0 ]; then
				LogsWriteShow $fun_name " - Firewall policy update failed... Please check and update manually"
			else
				RESTART_SVC_FW=true
			fi
		else
			LogsWriteShow $fun_name "WARNING: Firewall is running on the system!"
			LogsWriteShow $fun_name "Please use 'sudo uctv-wizard configure' in order to add necessary uctv firewall rules"
			RESTART_SVC_FW=true
		fi
	fi
	#Check for the UFW firewall
	if [ $fw_running -eq 1 ]; then
		CheckUFW
		if [ $? -eq 0 ]; then
			if [ "$is_agent" == false ]; then
				ConfigureUFW
				if [ $? -ne 0 ]; then
					LogsWriteShow $fun_name " - Uncomplicated Firewall (UFW) policy update failed... Please check and update manually"
				else
					RESTART_SVC_FW=true
				fi
			else
				LogsWriteShow $fun_name "WARNING: Uncomplicated Firewall (UFW) is running on the system!"
				LogsWriteShow $fun_name "Please use 'sudo uctv-wizard configure' in order to add necessary uctv firewall rules"
				RESTART_SVC_FW=true
			fi
		fi
	fi

    # Restart the service
    if [ "$RESTART_SVC" == "no-restart" ]; then
		LogsWriteShow $fun_name "################################################################################"
        LogsWriteShow $fun_name "WARNING! Some dependencies are missing!"
		LogsWriteShow $fun_name "please use 'sudo uctv-wizard pkg-install' to install the missing dependencies"
        RetVal=0
        return $RetVal
    fi

	if $is_agent; then
		#Check if upgrade.service is running
		temp=$(sudo systemctl status "$upgrade_service" > /dev/null 2>&1)
		if [ $? -eq 0 ]; then
			LogsWriteShow $fun_name " - UCT-V $upgrade_service found. Skipping restart...."
			return 0
		fi

		if $RESTART_SVC_FW; then
			return 0
		fi
	else
		if ! $RESTART_SVC_FW && ! $conf_change; then
			return 0
		fi
	fi

    LogsWriteShow $fun_name "Restarting the $Service service..."
	LogsWriteShow $fun_name " - stopping service"
    temp=`sudo systemctl stop $Service`
	LogsWriteShow $fun_name " - letting the dust settle"
	temp=`sleep 10`
	LogsWriteShow $fun_name " - starting service"
    temp=`sudo systemctl start $Service`
    if [ $? -eq 0 ]; then
        LogsWriteShow $fun_name " - $Service is running"
        RetVal=0
    else
        LogsWriteShow $fun_name "ERROR: $Service is not running"
        RetVal=1
    fi
    return $RetVal
}

##
## Uninstall UCT-V Software
##
function DoUninstall() {
	local fun_name="DoUninstall"
    LogsWriteShow $fun_name "Checking Installation..."
    Service="uctv"
    if [ "$Ext" == "rpm" ]; then
        temp=`rpm -q $Service 2>>/dev/null`
    else 
        temp=`dpkg -l $Service 2>>/dev/null`
    fi
    if [ $? -ne 0 ]; then    
        LogsWriteShow $fun_name " - $Service is not installed, nothing to do"
    else 
        temp=`sudo systemctl status $Service`
        if [ $? -eq 0 ]; then
            LogsWriteShow $fun_name " - Stopping service $Service"
            temp=`sudo systemctl stop $Service`
        fi
        LogsWriteShow $fun_name " - Uninstalling $Service"
        if [ "$Ext" == "rpm" ]; then
            temp=`sudo rpm -e $Service 2>>/dev/null`
        else 
            temp=`sudo dpkg -P $Service 2>>/dev/null`
        fi
        if [ $? -ne 0 ]; then
            echo "ERROR: Something went wrong with uninstall"
            return 1;
        fi
    fi

    #Removing any firewall rules
    ufw_ok=false
    fwcmd_ok=false
    command -v ufw &>/dev/null && ufw_ok=true
    command -v firewall-cmd &>/dev/null && fwcmd_ok=true

    if $ufw_ok || $fwcmd_ok; then
        for record in "${firewall_ports[@]}"; do
            IFS="|" read -r port proto direction name <<< "$record"
            if $fwcmd_ok; then
	        if [ "$direction" = "Inbound" ]; then
	            v4addr="source address='0.0.0.0/0'"
	            v6addr="source address='::/0'   "
                else
                    v4addr="destination address='0.0.0.0/0'"
	            v6addr="destination address='::/0'   "
                fi

		if [ "$port" = "47" ]; then
                    sudo firewall-cmd --permanent --remove-rich-rule="rule family='ipv4' $v4addr protocol value='${proto,,}' accept" > /dev/null 2> >(LogStderr "$fun_name")
                    sudo firewall-cmd --permanent --remove-rich-rule="rule family='ipv6' $v6addr protocol value='${proto,,}' accept" > /dev/null 2> >(LogStderr "$fun_name")
		else
                    sudo firewall-cmd --permanent --remove-rich-rule="rule family='ipv4' $v4addr port port='$port' protocol='${proto,,}' accept" > /dev/null 2> >(LogStderr "$fun_name")
                    sudo firewall-cmd --permanent --remove-rich-rule="rule family='ipv6' $v6addr port port='$port' protocol='${proto,,}' accept" > /dev/null 2> >(LogStderr "$fun_name")
		fi
            fi

            if $ufw_ok; then
                if [ "$direction" = "Inbound" ]; then
                    sudo ufw delete allow proto "$proto" from any to any port "$port" comment "$name" > /dev/null 2> >(LogStderr "$fun_name")
                else
                    if [ "$port" = "47" ]; then
                        sudo ufw delete allow out proto "$proto" from any to any comment "$name" > /dev/null 2> >(LogStderr "$fun_name")
                    else
                        sudo ufw delete allow out proto "$proto" from any to any port "$port" comment "$name" > /dev/null 2> >(LogStderr "$fun_name")
                    fi
                fi
            fi
            if [ "$port" = "47" ]; then
                LogsWriteShow $fun_name " - Removed policy $proto $direction $name"
            else
                LogsWriteShow $fun_name " - Removed policy $port $proto $direction $name"
            fi
        done

        if $fwcmd_ok; then
            sudo firewall-cmd --reload > /dev/null 2> >(LogStderr "$fun_name")
        fi

        if $ufw_ok; then
            sudo ufw reload > /dev/null 2> >(LogStderr "$fun_name")
        fi
    fi

    echo " - Uninstall successful"
    return 0
}

function UctvInternalCheck() {
	CheckPackagesPostinst
	if [ $? -eq 0 ]; then
		DoConfig configure agent
	else
		DoConfig configure agent no-restart
	fi

	return 0
}

function HelpPkgInstall () {
	local fun_name="HelpPkgInstall"

	LogsWriteShow $fun_name " - Usage: uctv-wizard pkg-install (-y)"
	LogsWriteShow $fun_name " - uctv-wizard pkg-install will checks if any dependencies are missing."  
	LogsWriteShow $fun_name " - Shows the version of the dependencies which are going to be installed and asks user if he wants to proceed with their installation."
	LogsWriteShow $fun_name " - By providing -y option (sudo uctv-wizard pkg-install -y), prompts will be skipped and all dependencies will be installed"
	return 0
}

function HelpPreCheck () {
	local fun_name="HelpPreCheck"

	LogsWriteShow $fun_name " - Usage: uctv-wizard pre-check"
	LogsWriteShow $fun_name " - uctv-wizard pre-check checks for the missing dependencies and if firewall is active on the system"  
	LogsWriteShow $fun_name " - It will display appropriate message with all the missing dependencies which can be installed with uctv-wizard pkg-install"
	return 0
}

function HelpDoConfig () {
	local fun_name="HelpDoConfig"

	LogsWriteShow $fun_name " - Usage: uctv-wizard configure (-y)"
	LogsWriteShow $fun_name " - uctv-wizard configure automatically adds interface configuration in uctv.conf file if  it is not configured already"  
	LogsWriteShow $fun_name " - If user provides his own configuration (gigamon-cloud.conf for 3PO is also possible) in /tmp location, uctv will use that one in configuration step"
	LogsWriteShow $fun_name " - If no configuration exists uctv will use all interfaces expect lo, with all permissions enabled"
	LogsWriteShow $fun_name " - If firewall is installed, user will have option to proceed with addition of necessary firewall rules"
	return 0
}

function HelpDoUninstall () {
	local fun_name="HelpDoUninstall"

	LogsWriteShow $fun_name " - Usage: uctv-wizard uninstall"
	LogsWriteShow $fun_name " - uctv-wizard uninstall will stop uctv service, remove firewall rules and uninstall it"  
	return 0
}

function Help () {
	local fun_name="Help"
	HELP_OP=$2

	if [ "$HELP_OP" == "pkg-install" ]; then
		HelpPkgInstall
	elif [ "$HELP_OP" == "configure" ]; then
		HelpDoConfig
	elif [ "$HELP_OP" == "pre-check" ]; then
		HelpPreCheck
	elif [ "$HELP_OP" == "uninstall" ]; then
		HelpDoUninstall
	else
	LogsWriteShow $fun_name "Usage: uctv-wizard help [pre-check] | [pkg-install] | [configure] | [uninstall]"
	fi
	return 0
}

function PreCheck () {
	local fun_name="PreCheck"
	LogsWriteShow $fun_name "****Starting check for missing dependencies****"
	CheckPackages
	LogsWriteShow $fun_name ""
	LogsWriteShow $fun_name "****Starting firewall check****"
	CheckFirewall
	if [ $fw_running -eq 1 ]; then
		CheckUFW
	fi
	return 0
}

function Usage() {
     echo -e "Usage: $(basename $0) [pre-check] | [pkg-install] | [configure] | [uninstall] | [help]\n"  
}

##
## Main Processing
##
initialize_logs
if [ "$#" -lt 1 ]; then
    echo -e "ERROR: Missing Argument\n"
    Usage
    exit 1
fi
if ! [[ "$1" =~ ^(pre-check|pkg-install|configure|uninstall|internal-pkg-check|help|)$ ]]; then 
    echo -e "ERROR: Invalid Argument\n"
    Usage
    exit 1
fi

if [ "$1" != "help" ]; then
	SetExt
fi

if [ $? -ne 0 ]; then
    echo "ERROR: It doesn't appear that is OS is supported"
    exit 1
fi
if [ "$1" == "pkg-install" ]; then
    PkgInstall "$@"
    ExitVal=$?
elif [ "$1" == "configure" ]; then
    DoConfig "$@"
    ExitVal=$?
elif [ "$1" == "pre-check" ]; then
    PreCheck
    ExitVal=$?
elif [ "$1" == "uninstall" ]; then
    DoUninstall
    ExitVal=$?
elif [ "$1" == "help" ]; then
    Help "$@"
    ExitVal=$?
elif [ "$1" == "internal-pkg-check" ]; then
    if [ "$2" == "uctv_postinst_call" ]; then
      UctvInternalCheck
      ExitVal=$?
    else
      echo "ERROR: Only UCTV Service can do this call." >> "$tmp"
      ExitVal=1
    fi
else
    echo "ERROR: Issue with Argument"
    ExitVal=1
fi
exit $ExitVal
