#!/bin/bash

# Fetches PID from process name 
#
# Arguments:
#   - process name 
#
# Return Value:
#   - PID/s associated with process
#
display_usage() {
        echo -e "\nUsage: $0 -p (--process-name)\n"

        #example: Fetching ifindex and if_name from container-Id
        echo -e "Example1: ./find_pid_by_procname -p apache2\n"
}
if [  $# -lt 2 ]
then
  display_usage
  exit 1
else
  while [ "$1" != "" ]; do
      PARAM="$1"
      shift
      VALUE="$1"
      case $PARAM in
          -h | --help)
              display_usage
              exit
              ;;
          -p | --process-name)
              proc_name=$VALUE
              ;;
          *)
              echo "ERROR: unknown parameter \"$PARAM\""
              display_usage
              exit 1
              ;;
      esac
      shift
  done
fi
LIST=$(pidof $proc_name)
for PID in $(echo $LIST)
do
        echo $PID
done
