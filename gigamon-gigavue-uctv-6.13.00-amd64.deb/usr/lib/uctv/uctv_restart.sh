#!/bin/bash
#
# Copyright (c) 2015 Gigamon Inc. All Rights Reserved.
#

GVTAP_AGENT_PROG_DIR=/usr/lib/uctv
GVTAP_AGENT_DATA_DIR=/var/lib/uctv

${GVTAP_AGENT_PROG_DIR}/uctv_stop.sh
${GVTAP_AGENT_PROG_DIR}/uctv_start.sh

