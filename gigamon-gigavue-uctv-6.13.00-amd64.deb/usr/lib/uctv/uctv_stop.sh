#!/bin/bash
#
# Copyright (c) 2015 Gigamon Inc. All Rights Reserved.
#
set -x
#FIXME
GVTAP_AGENT_PROG_DIR=/usr/lib/uctv
GVTAP_AGENT_DATA_DIR=/var/lib/uctv
export GVTAP_AGENT_PROG_DIR=$GVTAP_AGENT_PROG_DIR
export GVTAP_AGENT_DATA_DIR=$GVTAP_AGENT_DATA_DIR

GVTAP_AGENT_SERVER=$GVTAP_AGENT_PROG_DIR/uctvd
GVTAP_AGENT_CMD=$GVTAP_AGENT_PROG_DIR/uctvl
RET_CODE=0

PID=$(ps aux | awk '! /awk/ && /uctvd/ {print $2; exit}')
if [ $PID > 0 ]; then
	# Inidcate agent is exitinga
	LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 $GVTAP_AGENT_CMD agent-exiting
	if [ $? -ne 0 ]; then
		echo "Error: UCT-V exiting failure"
		RET_CODE=1
	fi

	# Destroy any existing interface mirrors
	MIRRORS=`LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 $GVTAP_AGENT_CMD mirror-list`
	for MIRROR in $MIRRORS; do
		LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 $GVTAP_AGENT_CMD mirror-destroy $MIRROR
		if [ $? -ne 0 ]; then
			echo "Warning: Could not destroy interface mirror: $MIRROR"
		fi
		
	done

	# Stop G-vTAP agent
	LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 $GVTAP_AGENT_CMD uctv-ctl --stop
	if [ $? -ne 0 ]; then
		echo "Error: UCT-V stop failure"
		RET_CODE=1
	fi

	# Wait for G-vTAP agent to terminate
	sleep 2

	# Reset G-vTAP agent
	LD_LIBRARY_PATH=/usr/lib/uctv/ssl-lib64 $GVTAP_AGENT_CMD uctv-ctl --reset
	if [ $? -ne 0 ]; then
		echo "Error: UCT-V reset failure"
		RET_CODE=1
	fi
	rm /var/run/uctv.pid
else
	echo "Error: UCT-V is not running"
	RET_CODE=1
fi

sleep 3
# Check if uctvd is running and stop it
PID=$(pgrep -f "uctvd" | head -n 1)
if [ ${PID} > 0 ]; then
	# Stop uctvd process
	kill -9 $PID
	if [ $? -ne 0 ]; then
		echo "Error: UCT-V uctvd process stop failure"
		RET_CODE=1
	fi

	# Wait for uctvd process to terminate
	sleep 2
fi

exit ${RET_CODE}
