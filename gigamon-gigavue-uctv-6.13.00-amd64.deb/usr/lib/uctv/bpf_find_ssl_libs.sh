cd /
LIBS_LIST=$(find . -name libssl.so.* | grep '/usr/lib/uctv/ssl-lib64\|/snap/core' -v | cut -c 2-)
for LIB in $(echo $LIBS_LIST)
do
	SYM_LINK=`ls -l $LIB | grep ">"`
	if [ -z "$SYM_LINK" ]
	then
		echo $LIB
		case "$LIB" in
			*libssl.so.3*) echo "300" ;;
			*) echo $(grep --text -o 'OpenSSL [[:digit:]][^ ]*' $LIB | head -1 | tr -d "." | cut -c9-11) ;;
		esac
	fi
done
