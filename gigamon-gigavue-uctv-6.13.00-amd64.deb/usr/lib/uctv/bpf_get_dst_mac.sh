#!/bin/bash

# Fetches L3 and L2 header information from the fd
#
# Arguments:
#   - containerId       (ID of the container)
#   - fd
#   - PID
#
# Return Value:
#   - ifIndex of the container
#   - ifName/s in the container
#
display_usage() {
	echo -e "\nUsage: $0 -r(--remote_addr) remote-ip -i(--interface-name) iface-name -f(--family) ip6/ip4\n"

        #example: Fetching ifindex and if_name from container-Id
        echo -e "Example1: ./bpf_get_dst_mac.sh -r 10.1.1.57 -i ens3 -f ip6\n"
}
ip_family=ip4
if [  $# -lt 4 ]
then
  display_usage
  exit 1
else
  while [ "$1" != "" ]; do
      PARAM="$1"
      shift
      VALUE="$1"

      case $PARAM in
          -h | --help)
              display_usage
              exit
              ;;
          -r | --remote_ip)
              remote_ip=$VALUE
              ;;
          -i | -iface_name)
               iface_name=$VALUE
              ;;
          -f | --family)
               ip_family=$VALUE
              ;;
          *)
              echo "ERROR: unknown parameter \"$PARAM\""
              display_usage
              exit 1
              ;;
      esac
      shift
  done
fi

if [ "$ip_family" = "ip4" ]; then
	default_gw_ip=`ip route show | grep default | grep $iface_name | awk '{print $3}'`
	if [ -z "$default_gw_ip" ]
	then
		default_gw_ip=`ip route show | grep default | awk '{print $3}'`
	fi
else
	default_gw_ip=`ip -6 route show | grep default | grep $iface_name | awk '{print $3}'`
	if [ -z "$default_gw_ip" ]
	then
		default_gw_ip=`ip -6 route show | grep default | awk '{print $3}'`
	fi
	regex='^([0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}$'
	if [[ $default_gw_ip =~ $regex ]]; then
		:
	else
		default_gw_ip=`ip -6 route show | grep nexthop | awk 'NR==1{print $3}'`
	fi

fi
remote_mac=`ip neigh show | grep "$remote_ip " | awk '{print $5}' `
if [ -z "$remote_mac" ]
then
	remote_mac=`ip neigh show | grep "$default_gw_ip " | awk '{print $5}'`
fi
echo $remote_mac
echo $default_gw_ip
